# DDSName
Blender Extension to easily rename objects and object data. 
